//
//  QDNormalButtonViewController.h
//  qmuidemo
//
//  Created by QMUI Team on 16/10/12.
//  Copyright (c) 2016年 QMUI Team. All rights reserved.
//

#import "QDCommonViewController.h"

@interface QDNormalButtonViewController : QDCommonViewController

@end
