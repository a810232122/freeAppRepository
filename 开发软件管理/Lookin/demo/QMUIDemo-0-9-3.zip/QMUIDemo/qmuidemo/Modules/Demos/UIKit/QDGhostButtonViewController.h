//
//  QDGhostButtonViewController.h
//  qmuidemo
//
//  Created by QMUI Team on 15/5/23.
//  Copyright (c) 2015年 QMUI Team. All rights reserved.
//

#import "QDCommonViewController.h"

@interface QDGhostButtonViewController : QDCommonViewController

@end
