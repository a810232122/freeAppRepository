//
//  QDSearchViewController.h
//  qmuidemo
//
//  Created by QMUI Team on 16/5/25.
//  Copyright © 2016年 QMUI Team. All rights reserved.
//

#import "QDCommonTableViewController.h"

@interface QDSearchViewController : QDCommonTableViewController

@end
