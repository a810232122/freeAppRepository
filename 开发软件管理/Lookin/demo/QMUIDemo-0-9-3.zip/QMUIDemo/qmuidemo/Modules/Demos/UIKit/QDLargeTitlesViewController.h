//
//  QDLargeTitlesViewController.h
//  qmuidemo
//
//  Created by ziezheng on 2019/7/11.
//  Copyright © 2019 QMUI Team. All rights reserved.
//

#import "QDCommonListViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface QDLargeTitlesViewController : QDCommonListViewController

@end

NS_ASSUME_NONNULL_END
