//
//  QDOrientationViewController.h
//  qmuidemo
//
//  Created by QMUI Team on 2017/6/23.
//  Copyright © 2017年 QMUI Team. All rights reserved.
//

#import "QDCommonTableViewController.h"

@interface QDOrientationViewController : QDCommonTableViewController

@end
