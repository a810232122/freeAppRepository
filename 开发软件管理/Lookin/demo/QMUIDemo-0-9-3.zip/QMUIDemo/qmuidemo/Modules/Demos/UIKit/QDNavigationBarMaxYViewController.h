//
//  QDNavigationBarMaxYViewController.h
//  qmuidemo
//
//  Created by MoLice on 2019/A/13.
//  Copyright © 2019 QMUI Team. All rights reserved.
//

#import "QDCommonListViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface QDNavigationBarMaxYViewController : QDCommonListViewController

@property(nonatomic, assign) BOOL navigationBarHidden;
@end

NS_ASSUME_NONNULL_END
