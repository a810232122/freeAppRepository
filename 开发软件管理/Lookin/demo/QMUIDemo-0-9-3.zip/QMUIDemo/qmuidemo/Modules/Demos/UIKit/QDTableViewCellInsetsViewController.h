//
//  QDTableViewCellInsetsViewController.h
//  qmuidemo
//
//  Created by QMUI Team on 2016/10/11.
//  Copyright © 2016年 QMUI Team. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "QDCommonTableViewController.h"

@interface QDTableViewCellInsetsViewController : QDCommonTableViewController

@end
