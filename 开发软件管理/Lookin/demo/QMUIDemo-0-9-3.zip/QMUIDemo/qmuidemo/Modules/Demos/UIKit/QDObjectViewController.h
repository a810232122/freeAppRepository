//
//  QDObjectViewController.h
//  qmuidemo
//
//  Created by QMUI Team on 2017/3/24.
//  Copyright © 2017年 QMUI Team. All rights reserved.
//

#import "QDCommonTableViewController.h"

@interface QDObjectViewController : QDCommonTableViewController

@end
