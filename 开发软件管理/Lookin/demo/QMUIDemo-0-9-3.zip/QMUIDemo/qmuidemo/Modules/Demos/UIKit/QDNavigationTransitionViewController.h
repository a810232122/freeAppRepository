//
//  QDNavigationTransitionViewController.h
//  qmuidemo
//
//  Created by QMUI Team on 2018/2/5.
//  Copyright © 2018年 QMUI Team. All rights reserved.
//

#import "QDCommonViewController.h"

@interface QDNavigationTransitionViewController : QDCommonViewController

@end
