//
//  QDImageViewViewController.h
//  qmuidemo
//
//  Created by MoLice on 2019/A/28.
//  Copyright © 2019 QMUI Team. All rights reserved.
//

#import "QDCommonTableViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface QDImageViewViewController : QDCommonTableViewController

@end

NS_ASSUME_NONNULL_END
