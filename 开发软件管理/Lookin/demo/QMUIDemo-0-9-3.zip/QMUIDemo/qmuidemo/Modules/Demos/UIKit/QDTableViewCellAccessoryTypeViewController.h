//
//  QDTableViewCellAccessoryTypeViewController.h
//  qmuidemo
//
//  Created by QMUI Team on 2017/6/19.
//  Copyright © 2017年 QMUI Team. All rights reserved.
//

#import "QDCommonTableViewController.h"

@interface QDTableViewCellAccessoryTypeViewController : QDCommonTableViewController

@end
