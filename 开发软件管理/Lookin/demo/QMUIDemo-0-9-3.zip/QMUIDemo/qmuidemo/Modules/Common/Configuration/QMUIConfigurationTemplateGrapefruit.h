//
//  QMUIConfigurationTemplate.h
//
//  Created by QMUI Team on 15/3/29.
//  Copyright (c) 2015年 QMUI Team. All rights reserved.
//

#import "QMUIConfigurationTemplate.h"

@interface QMUIConfigurationTemplateGrapefruit : QMUIConfigurationTemplate

@end
